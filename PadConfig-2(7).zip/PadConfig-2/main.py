import os
import discord
from discord.ext import commands, tasks
from flask import Flask
from threading import Thread
import itertools
import json
from datetime import datetime

# ---------- KEEP ALIVE ----------
app = Flask("")

@app.route("/")
def home():
    return "Bot en ligne !"

def run():
    app.run(host="0.0.0.0", port=8080)

def keep_alive():
    Thread(target=run).start()

keep_alive()

# ---------- CONFIG BOT ----------
TOKEN = os.getenv("DISCORD_TOKEN")
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# ---------- STATUS EN DND ----------
statuses = itertools.cycle([
    "Surveillance PF RP 🔐",
    "Mon Développeur Ultra Padlok ✅",
    "Surveillance Des Serveurs 🔍",
    "Surveillance Des Sanctions 👢",
    "Je Suis Disponible ❓",
    "Je Suis En Développement ⚒️"
])

@tasks.loop(seconds=4)
async def change_status():
    activity = discord.Activity(type=discord.ActivityType.listening, name=next(statuses))
    await bot.change_presence(status=discord.Status.dnd, activity=activity)

@bot.event
async def on_ready():
    print(f"{bot.user} est connecté !")
    change_status.start()
    if not os.path.exists("modlogs.json"):
        with open("modlogs.json", "w") as f:
            json.dump({}, f)

# ---------- FONCTIONS MODLOG ----------
def load_modlogs():
    with open("modlogs.json", "r") as f:
        return json.load(f)

def save_modlogs(data):
    with open("modlogs.json", "w") as f:
        json.dump(data, f, indent=4)

def add_modlog(user_id, log_type, mod_name, reason):
    data = load_modlogs()
    timestamp = datetime.utcnow().strftime("%d/%m/%Y %H:%M UTC")
    entry = {
        "type": log_type,
        "mod": mod_name,
        "reason": reason,
        "date": timestamp
    }
    data.setdefault(str(user_id), []).append(entry)
    save_modlogs(data)

# ---------- COMMANDES ----------

# WARN
@bot.command()
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason="Aucune raison fournie"):
    add_modlog(member.id, "WARN", ctx.author.name, reason)

    # Notification au membre en MP
    embed_user = discord.Embed(
        title="⚠️ WARN",
        description="Vous avez reçu un avertissement !",
        color=discord.Color.orange()
    )
    embed_user.add_field(name="Serveur", value=f"🔐 {ctx.guild.name} 🔐", inline=False)
    embed_user.add_field(name="Modérateur", value=ctx.author.name, inline=False)
    embed_user.add_field(name="Raison", value=reason, inline=False)
    embed_user.set_footer(text="⚠️ Merci de respecter les règles du serveur !")
    await member.send(embed=embed_user)

    # Notification dans le salon
    embed_salon = discord.Embed(
        title="⚠️ WARN EFFECTUÉ",
        description=f"{member.mention} a reçu un **warn**",
        color=discord.Color.orange()
    )
    embed_salon.add_field(name="Modérateur", value=ctx.author.mention, inline=False)
    embed_salon.add_field(name="Raison", value=reason, inline=False)
    embed_salon.set_footer(text="✅ Cette action est enregistrée.")
    await ctx.send(embed=embed_salon)

# UNWARN
@bot.command()
@commands.has_permissions(manage_messages=True)
async def unwarn(ctx, member: discord.Member, number: int):
    data = load_modlogs()
    user_logs = data.get(str(member.id), [])
    warns = [w for w in user_logs if w["type"] == "WARN"]
    if 0 < number <= len(warns):
        removed_warn = warns[number-1]
        user_logs.remove(removed_warn)
        data[str(member.id)] = user_logs
        save_modlogs(data)

        embed_user = discord.Embed(
            title="✅ WARN RETIRÉ",
            description="Un avertissement vous a été retiré.",
            color=discord.Color.green()
        )
        embed_user.add_field(name="Serveur", value=f"🔐 {ctx.guild.name} 🔐", inline=False)
        embed_user.add_field(name="Modérateur", value=ctx.author.name, inline=False)
        embed_user.add_field(name="Raison", value=removed_warn["reason"], inline=False)
        embed_user.set_footer(text="⚠️ Merci de respecter les règles du serveur !")
        await member.send(embed=embed_user)

        embed_salon = discord.Embed(
            title="✅ WARN RETIRÉ",
            description=f"{member.mention} a été **unwarn**",
            color=discord.Color.green()
        )
        embed_salon.add_field(name="Modérateur", value=ctx.author.mention, inline=False)
        embed_salon.add_field(name="Raison", value=removed_warn["reason"], inline=False)
        await ctx.send(embed=embed_salon)
    else:
        await ctx.send(embed=discord.Embed(
            description="⚠️ Numéro de warn invalide !",
            color=discord.Color.red()
        ))

# KICK
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="Aucune raison fournie"):
    try:
        await member.kick(reason=reason)

        embed_user = discord.Embed(
            title="👢 KICK",
            description=f"Vous avez été **kicked** du serveur.",
            color=discord.Color.red()
        )
        embed_user.add_field(name="Modérateur", value=ctx.author.name, inline=False)
        embed_user.add_field(name="Raison", value=reason, inline=False)
        embed_user.add_field(name="Serveur", value=f"🔐 {ctx.guild.name} 🔐", inline=False)
        embed_user.set_footer(text="⚠️ Merci de respecter les règles du serveur !")
        await member.send(embed=embed_user)

        embed_salon = discord.Embed(
            title="👢 KICK",
            description=f"{member.mention} a été **kicked**",
            color=discord.Color.red()
        )
        embed_salon.add_field(name="Modérateur", value=ctx.author.mention, inline=False)
        embed_salon.add_field(name="Raison", value=reason, inline=False)
        await ctx.send(embed=embed_salon)

        add_modlog(member.id, "KICK", ctx.author.name, reason)

    except Exception as e:
        await ctx.send(embed=discord.Embed(
            description=f"⛔ Impossible de kick {member.mention}: {str(e)}",
            color=discord.Color.red()
        ))

# BAN PERM
@bot.command()
@commands.has_permissions(ban_members=True)
async def banperm(ctx, member: discord.Member, *, reason="Aucune raison fournie"):
    try:
        await member.ban(reason=reason)

        embed_user = discord.Embed(
            title="⛔ BAN PERM",
            description=f"Vous avez été **banni du serveur**.",
            color=discord.Color.dark_red()
        )
        embed_user.add_field(name="Modérateur", value=ctx.author.name, inline=False)
        embed_user.add_field(name="Raison", value=reason, inline=False)
        embed_user.add_field(name="Serveur", value=f"🔐 {ctx.guild.name} 🔐", inline=False)
        embed_user.set_footer(text="⚠️ Merci de respecter les règles du serveur !")
        await member.send(embed=embed_user)

        embed_salon = discord.Embed(
            title="⛔ BAN PERM",
            description=f"{member.mention} a été **banni**",
            color=discord.Color.dark_red()
        )
        embed_salon.add_field(name="Modérateur", value=ctx.author.mention, inline=False)
        embed_salon.add_field(name="Raison", value=reason, inline=False)
        await ctx.send(embed=embed_salon)

        add_modlog(member.id, "BAN PERM", ctx.author.name, reason)

    except Exception as e:
        await ctx.send(embed=discord.Embed(
            description=f"⛔ Impossible de ban {member.mention}: {str(e)}",
            color=discord.Color.red()
        ))

# MODLOGS
@bot.command()
@commands.has_permissions(manage_messages=True)
async def modlogs(ctx, member: discord.Member):
    data = load_modlogs()
    user_logs = data.get(str(member.id), [])
    if not user_logs:
        return await ctx.send(embed=discord.Embed(
            description=f"⚠️ {member.mention} n'a aucun log.",
            color=discord.Color.greyple()
        ))
    for log in user_logs:
        color = discord.Color.orange() if log["type"] == "WARN" else discord.Color.red()
        embed = discord.Embed(
            title=f"{log['type']}",
            color=color
        )
        embed.add_field(name="Serveur", value=f"🔐 {ctx.guild.name} 🔐", inline=False)
        embed.add_field(name="Modérateur", value=log["mod"], inline=False)
        embed.add_field(name="Raison", value=log["reason"], inline=False)
        embed.add_field(name="Date", value=log["date"], inline=False)
        embed.set_footer(text="⚠️ Merci de respecter les règles du serveur !")
        await ctx.send(embed=embed)

# CLEAR
@bot.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    if amount < 1:
        return await ctx.send(embed=discord.Embed(
            description="⚠️ Vous devez spécifier un nombre supérieur à 0.",
            color=discord.Color.red()
        ))
    deleted = await ctx.channel.purge(limit=amount)
    await ctx.send(embed=discord.Embed(
        description=f"🧹 {len(deleted)} messages supprimés par {ctx.author.mention}",
        color=discord.Color.blue()
    ), delete_after=5)

# HELP COMMAND
@bot.command()
@commands.has_permissions(manage_messages=True)
async def helpcommand(ctx):
    embed = discord.Embed(
        title="📜 Commandes du Bot",
        description="Voici toutes les commandes disponibles et leurs permissions requises :",
        color=discord.Color.blue()
    )

    embed.add_field(
        name="!warn @membre <raison>",
        value="Avertir un membre. Permission : Gérer les messages",
        inline=False
    )
    embed.add_field(
        name="!unwarn @membre <numéro_warn>",
        value="Retirer un avertissement. Permission : Gérer les messages",
        inline=False
    )
    embed.add_field(
        name="!kick @membre <raison>",
        value="Expulser un membre du serveur. Permission : Expulser des membres",
        inline=False
    )
    embed.add_field(
        name="!banperm @membre <raison>",
        value="Bannir un membre définitivement. Permission : Bannir des membres",
        inline=False
    )
    embed.add_field(
        name="!modlogs @membre",
        value="Voir tous les logs de modération d'un membre. Permission : Gérer les messages",
        inline=False
    )
    embed.add_field(
        name="!clear <nombre>",
        value="Supprimer un certain nombre de messages. Permission : Gérer les messages",
        inline=False
    )

    embed.set_footer(text="💡 Les messages de modération sont envoyés en MP au membre concerné.")
    await ctx.send(embed=embed)

# ---------- LANCEMENT DU BOT ----------
bot.run(TOKEN)
